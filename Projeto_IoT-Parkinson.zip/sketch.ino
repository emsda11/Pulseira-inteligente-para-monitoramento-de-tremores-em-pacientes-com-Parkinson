#include <Wire.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

Adafruit_MPU6050 mpu;

// ===== WIFI =====
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ===== MQTT =====
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;

const char* topicoDados  = "parkinson/paciente01/dados";
const char* topicoAlerta = "parkinson/paciente01/alerta";

WiFiClient espClient;
PubSubClient client(espClient);

// ===== HARDWARE =====
#define LED_ALERTA 5
#define BUZZER 4

float LIMITE_TREMOR = 2.2;

float axAnterior = 0;
float ayAnterior = 0;
float azAnterior = 0;

int contadorTremor = 0;

// =========================
// WIFI
// =========================

void conectarWiFi() {

  Serial.print("Conectando WiFi");

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi conectado!");
}

// =========================
// MQTT
// =========================

void conectarMQTT() {

  while (!client.connected()) {

    Serial.print("Conectando MQTT...");

    String clientId = "ESP32_Parkinson_";
    clientId += String(random(1000));

    if (client.connect(clientId.c_str())) {

      Serial.println("Conectado!");

    } else {

      Serial.print("Erro: ");
      Serial.println(client.state());

      delay(2000);
    }
  }
}

void setup() {

  Serial.begin(115200);

  Wire.begin(21, 22);

  pinMode(LED_ALERTA, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  digitalWrite(LED_ALERTA, LOW);

  conectarWiFi();

  client.setServer(mqtt_server, mqtt_port);

  Serial.println("==================================");
  Serial.println("Sistema IoT Parkinson");
  Serial.println("==================================");

  if (!mpu.begin()) {

    Serial.println("MPU6050 nao encontrado!");

    while (1) {
      delay(10);
    }
  }

  Serial.println("MPU6050 conectado!");

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  delay(1000);
}

void loop() {

  if (!client.connected()) {
    conectarMQTT();
  }

  client.loop();

  sensors_event_t aceleracao, giro, temp;

  mpu.getEvent(&aceleracao, &giro, &temp);

  float ax = aceleracao.acceleration.x;
  float ay = aceleracao.acceleration.y;
  float az = aceleracao.acceleration.z;

  float gx = giro.gyro.x;
  float gy = giro.gyro.y;
  float gz = giro.gyro.z;

  float variacao =
      abs(ax - axAnterior) +
      abs(ay - ayAnterior) +
      abs(az - azAnterior);

  if (variacao > LIMITE_TREMOR) {
    contadorTremor++;
  } else {
    contadorTremor = 0;
  }

  bool tremorDetectado = contadorTremor >= 3;

  if (tremorDetectado) {

    digitalWrite(LED_ALERTA, HIGH);
    tone(BUZZER, 1000);

    client.publish(
      topicoAlerta,
      "ALERTA: Possivel tremor detectado!"
    );

  } else {

    digitalWrite(LED_ALERTA, LOW);
    noTone(BUZZER);
  }

  String json = "{";

  json += "\"paciente\":\"Paciente 01\",";
  json += "\"ax\":" + String(ax,2) + ",";
  json += "\"ay\":" + String(ay,2) + ",";
  json += "\"az\":" + String(az,2) + ",";
  json += "\"gx\":" + String(gx,2) + ",";
  json += "\"gy\":" + String(gy,2) + ",";
  json += "\"gz\":" + String(gz,2) + ",";
  json += "\"variacao\":" + String(variacao,2) + ",";
  json += "\"contadorTremor\":" + String(contadorTremor) + ",";
  json += "\"tremor\":\"";
  json += tremorDetectado ? "SIM" : "NAO";
  json += "\"";
  json += "}";

  client.publish(topicoDados, json.c_str());

  Serial.println(json);

  axAnterior = ax;
  ayAnterior = ay;
  azAnterior = az;

  delay(1000);
}